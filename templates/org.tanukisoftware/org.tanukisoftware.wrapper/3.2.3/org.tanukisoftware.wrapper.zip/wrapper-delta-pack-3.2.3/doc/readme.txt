Java Service Wrapper

Complete documentation can be found by viewing doc/english/index.html
or by going to http://wrapper.tanukisoftware.org

